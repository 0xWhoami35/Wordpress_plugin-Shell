=== Web Recipe Clipper ===
Contributors: rocwing
Tags: recipe, gutenberg block, recipe generator, food, cooking, food
Donate link: https://www.leancodes.com/product/web-recipe-clipper/
Requires at least: 5.0.0
Tested up to: 5.1
Requires PHP: 5.2.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The plugin will add a block to gutenberg editor, you can paste a web recipe link, it will clip the content to generate the recipe in the editor.

== Description ==
The plugin will clip the recipe title, photo, description, instructions to your gutenberg editor, you can upload your own photos, edit the content, you can also add other contents.
When you save your post, it will show a well-formatted recipe on your post.
Sites we support, continuously added:
* [Allrecipes](http://www.allrecipes.com/)
* [Cooking](http://cooking.nytimes.com/)
* [PeachDish](https://www.peachdish.com/recipes)
* [Myrecipes](https://www.myrecipes.com)

== Installation ==
1.Install the plugin through the WordPress plugins screen.
2.Activate the plugin through the ‘Plugins’ screen in WordPress.
3.Search Web Recipe Clipper in your editor when you want to clip a recipe

== Frequently Asked Questions ==


== Screenshots ==
1. Find web recipe clipper block in your editor
2. Paste a web recipe link
3. It will generate recipe in your editor

== Changelog ==


== Upgrade Notice ==
